mapboxgl.accessToken = 'pk.eyJ1IjoiY25vZXJyZWdhYXJkIiwiYSI6ImNrOGE0cDllcDBjNGczbGw5amFzeXZpMDIifQ.MPPsRBFrqXWE6Lz8b2cXMw';

const knapper = document.querySelector("#knapper");
const flyKnapper = document.querySelector("#flyKnapper");

const map = new mapboxgl.Map( {
container: 'kart',
style: 'mapbox://styles/mapbox/light-v10', 

zoom: 12, 
center: [11.266238, 58.526007]
});

const changeMode = (evt) => {
    const knapp = evt.target;
    const mode = knapp.dataset.mode;
    map.setStyle(mode);
}


const flyTil = (evt) => {
    const knapp = evt.target;
    const lng = knapp.dataset.lng;
    const lat = knapp.dataset.lat;
    
    map.flyTo({
        center: [lng, lat],
        zoom: 15
    });
}

knapper.onclick = changeMode;
flyKnapper.onclick = flyTil;